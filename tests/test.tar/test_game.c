/*
** EPITECH PROJECT, 2018
** test_game
** File description:
** try not to segfault, good luck :)
*/

#include <criterion/criterion.h>
#include <stdlib.h>
#include "my.h"

Test (sokoban, check_game)
{
    int ac = 2;
    char **av = malloc(sizeof(char*) * 2);
    av[0] = "soko";
    av[1] = "tests/test_map";

    cr_assert_eq(game(ac, av), 84);
    free(av);
}

Test (sokoban, check_game2)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);

    cr_assert_eq(if_box(map, 1, 1), 2);
    cr_assert_eq(if_box(map, 8, 1), 1);
    cr_assert_eq(if_box(map, 5, 4), 0);
    cr_assert_eq(block(map), 1);
    free(map);
    free(pos);
}

Test (sokoban, check_reset)
{
    char *str = "tests/map_test2";
    char **map = get_map(str);
    int  *pos = player(str);
    int  mark = 1;

    reset(&map, &pos, &mark, str);
    cr_assert_eq(mark, 1);
    cr_assert_eq(if_box(map, 7, 3), 1);
    cr_assert_eq(if_box(map, 7, 7), 1);
    free(map);
    free(pos);
}

Test (sokoban, check_map_val)
{
    char *str = "tests/map_test";

    cr_assert_eq(map_val(str), 0);
}

Test (sokoban, check_size_map)
{
    char *str = "tests/map_test";
    char **map = get_map(str);

    cr_assert_eq(size_map(map), 1);
    map = get_map("tests/map_test3");
    cr_assert_eq(size_map(map), 0);
    free(map);
}
