/*
** EPITECH PROJECT, 2018
** test_level
** File description:
** try not to segfault, good luck :)
*/

#include <criterion/criterion.h>
#include <stdlib.h>
#include "my.h"

Test (sokoban, check_level)
{
    char *str = "tests/map_test4";

    cr_assert_eq(level(str), 1);
}
