/*
** EPITECH PROJECT, 2018
** test_map
** File description:
** try not to segfault, good luck :)
*/

#include <criterion/criterion.h>
#include <stdlib.h>
#include "my.h"

Test (sokoban, check_map)
{
    int i = 0;
    int j = 0;
    char *str = "tests/map_test";
    char **map = get_map(str);
    char **array = my_str_to_word_array("##########\n#        #\n#        #\
\n#   P    #\n#        #\n#   X    #\n#        #\n#   O    #\n#X       #\
\n##########\n", '\n');

    cr_assert_neq(map, NULL);
    while (map[i] != 0 && array[i] != 0) {
        j = 0;
        while (map[i][j] != '\0' && array[i][j] != '\0') {
            cr_assert_eq(map[i][j], array[i][j]);
            j++;
        }
        i++;
    }
    free(map);
    free(array);
}

Test (sokoban, check_map_null)
{
    char *str = "";
    char **map = get_map(str);

    cr_assert_eq(map, NULL);
}

Test (sokoban, check_player_position)
{
    char *str = "tests/map_test";
    int  *pos = player(str);

    cr_assert_neq(pos, NULL);
    cr_assert_eq(pos[0], 3);
    cr_assert_eq(pos[1], 4);
    free(pos);
}

Test (sokoban, check_nb_mark)
{
    char *str = "tests/map_test";
    int  mark = nb_mark(str);

    cr_assert_eq(mark, 1);
}
