/*
** EPITECH PROJECT, 2018
** direction_test
** File description:
** try not to segfault, good luck :)
*/

#include <criterion/criterion.h>
#include <stdlib.h>
#include "my.h"

Test (sokoban, check_direction)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);
    int  mark = 1;

    direction(map, pos, &mark, 2);
    cr_assert_eq(pos[0], 3);
    cr_assert_eq(pos[1], 3);
    free(map);
    free(pos);
}

Test (sokoban, check_step)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);
    int  mark = 1;

    step(map, pos, 2, &mark);
    cr_assert_eq(pos[0], 3);
    cr_assert_eq(pos[1], 3);
    free(map);
    free(pos);
}

Test (sokoban, check_out)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);

    cr_assert_eq(out(map, pos, 0), 1);
    free(map);
}

Test (sokoban, check_out2)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  pos[] = {0, 0};

    cr_assert_eq(out(map, pos, 1), 2);
    free(map);
}

Test (sokoban, check_out3)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  pos[] = {1, 1};

    cr_assert_eq(out(map, pos, 1), 0);
    free(map);
}
