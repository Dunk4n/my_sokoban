/*
** EPITECH PROJECT, 2018
** test_direction2
** File description:
** try not to segfault, good luck :)
*/

#include <criterion/criterion.h>
#include <stdlib.h>
#include "my.h"

Test (sokoban, check_char_map)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);

    char_map(map, pos, 1, 1);
    cr_assert_neq(pos[0], 10);
    cr_assert_neq(pos[1], 10);
    free(map);
    free(pos);
}

Test (sokoban, check_char_map2)
{
    char **map = my_str_to_word_array("##########\n#@       #\n#        #\
\n#   P    #\n#        #\n#   X    #\n#        #\n#   O    #\n#X       #\
\n##########\n", '\n');
    int  pos[] = {2, 2};

    char_map(map, pos, 1, 1);
    cr_assert_neq(pos[0], 10);
    cr_assert_neq(pos[1], 10);
    free(map);
}

Test (sokoban, check_step2)
{
    char **map = my_str_to_word_array("##########\n#@       #\n#        #\
\n#   P    #\n#        #\n#   X    #\n#        #\n#   O    #\n#X       #\
\n##########\n", '\n');
    int  pos[] = {2, 1};
    int  mark = 1;

    step(map, pos, 1, &mark);
    cr_assert_neq(pos[0], 10);
    cr_assert_neq(pos[1], 10);
    free(map);
}

Test (sokoban, check_display_map)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);

    display_map(map, pos);
    cr_assert_neq(pos[0], 5);
    cr_assert_neq(pos[1], 5);
    free(map);
    free(pos);
}

Test (sokoban, check_direction3)
{
    char *str = "tests/map_test";
    char **map = get_map(str);
    int  *pos = player(str);
    int  mark = 1;

    direction(map, pos, &mark, 0);
    direction(map, pos, &mark, 0);
    direction(map, pos, &mark, 0);
    cr_assert_neq(pos[0], 0);
    cr_assert_neq(pos[1], 0);
    free(map);
    free(pos);
}
