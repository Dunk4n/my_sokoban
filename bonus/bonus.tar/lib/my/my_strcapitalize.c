/*
** EPITECH PROJECT, 2018
** my_strcapitalize
** File description:
** make capitalize
*/

char    *my_strcapitalize(char *str)
{
    return (str);
}
